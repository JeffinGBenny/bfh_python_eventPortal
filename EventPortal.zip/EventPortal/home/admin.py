from django.contrib import admin
from .models import User_Details,EventDetails

admin.site.register(User_Details),
admin.site.register(EventDetails)
# Register your models here.
